﻿namespace ProductBusiness;

public class Class1
{

}

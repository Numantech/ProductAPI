﻿namespace ProductData;

public class Class1
{

}

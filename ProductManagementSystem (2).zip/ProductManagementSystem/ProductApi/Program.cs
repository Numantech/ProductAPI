// ProductApi/Program.cs
using Microsoft.EntityFrameworkCore;
using ProductBusiness.Interfaces;
using ProductBusiness.Services;
using ProductData.IRepositories;
using ProductData.Models;
using ProductData.Repositories;

var builder = WebApplication.CreateBuilder(args);

// Get connection string from configuration (appsettings.json)
var connectionString = builder.Configuration.GetConnectionString("DefaultConnection");

// Register the ProductDbContext to use SQL Server
builder.Services.AddDbContext<ProductDbContext>(options =>
    options.UseSqlServer(connectionString));  // UseSqlServer instead of UseInMemoryDatabase

// Register repositories and services
builder.Services.AddScoped<IProductRepository, ProductRepository>();
builder.Services.AddScoped<IProductService, ProductService>();

// Add services to the container.
builder.Services.AddControllers();

var app = builder.Build();

// Configure the HTTP request pipeline.
app.UseAuthorization();

app.MapControllers();

app.Run();
